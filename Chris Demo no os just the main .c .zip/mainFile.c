/**
Demo is you select a number with the joystick push the top button to save it in the queue, the bottom button is used to display theses inputs in batches of 10.

Christopher Andrew
 */

#include "Queue.h"
#include <stdint.h>
#include "BSP.h"
#include "Profile.h"
#include "Texas.h"
#include "CortexM.h"
#include "os.h"
#include "stdio.h"
#include <stdlib.h>
//#include "Filesystem.h"	// only used for erasing the file system (in test fnc)

//#include "Queue.h"

//  Testing the OS
// Task   Type           When to Run
// TaskA  data producer  periodically every 20 ms (sleep)
// TaskB  data consumer  after TaskA finishes
// TaskC  data producer  periodically every 50 ms (sleep)
// TaskD  data consumer  after TaskC finishes
// TaskE  data producer  periodically every 100 ms (sleep)
// TaskF  data consumer  after TaskE finishes
// TaskG  periodic thread - runs depending on Periodic schedule
// TaskH  Signalled by TaskG

struct gate QGate;
struct gate LCDGate;
struct queue* Q;

uint16_t x, y;
		uint8_t b;
		
int32_t blankSignal;

//blindly polls input button and joystick dumping joystick data into a global
void TaskA(void)
{
	BSP_Joystick_Init();
	BSP_Button1_Init();
	OS_gate_init(&QGate);
	Q = OS_queue_create();
	while(1)
	{
		
		
		BSP_Joystick_Input(&x,&y,&b);
		if(!BSP_Button1_Input())
		{
			
			OS_gate_entry(&QGate);
			uint16_t* joyData  = malloc(sizeof(uint16_t));
			*joyData = x;
			//OS_Sleep(1); //make sure it can hit the trigger
			OS_queue_push(joyData,Q);
			OS_gate_exit(&QGate);
			
			OS_Sleep(500);
		}
	}
}

//manges lcd display and display results
void TaskB(void)
{
	//thread init
	BSP_Button2_Init();
	BSP_LCD_FillScreen(0); 
	OS_gate_init(&LCDGate);
	while(1)
	{
		OS_gate_entry(&LCDGate);
		//check if you need to dumpt items from the queue
		if(!BSP_Button2_Input())
		{
			//attempt to draw out 10 numbers from the queue
			//null pointers returned are printed as 0
				for(int i = 0; i< 10; i++)
				{
					BSP_LCD_SetCursor(0,2+i);
					
					//gate is used to protect the queue from the data input
					//queues have a internal mutex technicly but this does not interfer and demonstrates gates functioning
					OS_gate_entry(&QGate);
					if(OS_queue_peak(Q))
					{
						int* tempData = OS_queue_pop(Q);
						BSP_LCD_OutUDec4(*tempData, 0xFFFF);
						free(tempData);
					}
					else
					{
						BSP_LCD_OutUDec4(0, 0xFFFF);
					}
					OS_gate_exit(&QGate);	
				}
			
			OS_Signal(&blankSignal);
			OS_Sleep(500);
			
		}
		
		//display the current joystick values
		BSP_LCD_SetCursor(1,1);
		BSP_LCD_OutUDec4(x, 0xFFFF);
		
		OS_gate_exit(&LCDGate);
		OS_Sleep(100);
	}
}

//aperiodic event thread, waits 5 seconds after being triggered before blanking the screen
void TaskC(void)
{
	while(1)
	{
	//BSP_LCD_FillScreen(0);  
	OS_Wait(&blankSignal);
	OS_Sleep(5000);
	OS_gate_entry(&LCDGate);
	BSP_LCD_FillScreen(0); 
	OS_gate_exit(&LCDGate);
		
	}
}

//make sure the program does not think it broke and provides a very basic heartbeat
void TaskD(void)
{
	int spining = 0;
	while(1)
		spining++;
}

int main(void){
  OS_Init();
	BSP_LCD_Init();
	OS_InitSemaphore(&blankSignal,0);
	
	// Create Queue
	//testQueue = OS_queue_create();

	// Main threads
	int32_t threads[4] = { (int32_t)&TaskA, (int32_t)&TaskB, (int32_t)&TaskC,(int32_t)&TaskD};
	OS_AddThreads(4,threads);
													
//  TExaS_Init(GRADESTEP1, 1000);    // initialize the Lab 4 grader
  OS_Launch(BSP_Clock_GetFreq()/1000);
  return 0;             // this never executes
}


